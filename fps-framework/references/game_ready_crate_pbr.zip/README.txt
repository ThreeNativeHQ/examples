GAME-READY CRATE PBR MATERIAL
================================

Texture resolution:
- Atlas: 2048 x 1024
- Each atlas tile: 512 x 512
- Base Color: sRGB
- Normal / Roughness / Metallic / AO / Height / ORM: Linear / non-color data

Included maps:
- crate_basecolor_2048x1024.png
- crate_normal_2048x1024.png       (OpenGL tangent-space normal)
- crate_roughness_2048x1024.png
- crate_metallic_2048x1024.png
- crate_ao_2048x1024.png
- crate_height_2048x1024.png
- crate_orm_2048x1024.png          (R=AO, G=Roughness, B=Metallic)
- faces_basecolor/*.png             (six easy per-face albedo textures)

Atlas slots / normalized UVs (OpenGL UV convention):
front       U 0.00–0.25   V 0.50–1.00
back        U 0.25–0.50   V 0.50–1.00
left        U 0.50–0.75   V 0.50–1.00
right       U 0.75–1.00   V 0.50–1.00
top         U 0.00–0.25   V 0.00–0.50
bottom      U 0.25–0.50   V 0.00–0.50
variant_a   U 0.50–0.75   V 0.00–0.50
variant_b   U 0.75–1.00   V 0.00–0.50

Recommended material settings:
- BaseColor / map: sRGB
- Normal: tangent space, strength around 0.7–1.2
- Roughness: use as linear map
- Metallic: use as linear map
- AO: use as linear map
- ORM: convenient for glTF/Three.js packed material workflows
- Height: optional; keep displacement subtle

Three.js:
- colorSpace = THREE.SRGBColorSpace only for Base Color
- Normal/Roughness/Metallic/AO/ORM must remain linear
- If using AO, geometry needs uv1/uv2 as appropriate for your Three.js version/material setup.

Important:
This set is now structurally usable as a game PBR texture package.
The source artwork was AI-generated from the referenced crate look, so the PBR maps are derived rather than photogrammetry-authored.
